<?php
$host = "localhost";
$usuario = "root";
$clave = "";
$base_de_datos = "system";

// Crear la conexión
$conn = new mysqli($host, $usuario, $clave, $base_de_datos);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
