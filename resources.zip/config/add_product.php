<?php
include "../config/db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $stock = $_POST['stock'];
    $precio = $_POST['precio'];
    $descripcion = $_POST['descripcion'];

    $sql = "INSERT INTO articulos (nombre, descripcion, stock, precio) 
            VALUES ('$nombre', '$descripcion', $stock, $precio)";

    if ($conn->query($sql) === TRUE) {
        echo "<script>window.location.href='../views/articulos.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
