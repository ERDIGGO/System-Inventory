<?php
session_start();

// Incluir el archivo de conexión
include('db.php');

// Validación de usuario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Consulta SQL para validar usuario
    $sql = "SELECT * FROM usuarios WHERE username = '$username' AND password = '$password'";
    $resultado = $conn->query($sql);
    
    if ($resultado->num_rows > 0) {
        // Guardar nombre de usuario en la sesión
        $_SESSION['username'] = $username; 

        // Obtener la cantidad de artículos
        $sql_articulos = "SELECT COUNT(*) AS total FROM articulos";
        $resultado_articulos = $conn->query($sql_articulos);

        if ($resultado_articulos) {
            $row = $resultado_articulos->fetch_assoc();
            $_SESSION['total_articulos'] = $row['total']; // Guardar cantidad de artículos en sesión
        } else {
            $_SESSION['total_articulos'] = 0; // Si hay un error, valor por defecto
        }

        header("Location: ../views/index.php"); // Redirigir al panel de control
        
        exit();
    } else {
        echo "Username o password incorrectos.";
    }
}

// Cerrar conexión
$conn->close();
?>