<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./resources/css/styles.css">
    <link rel="icon" href="views/models/icon/favicon.ico" type="image/x-icon">
    <title>Auth - system</title>
</head>
<body>

<div class="container-form">
        <form action="./config/auth.php" method="POST">
            <h1>LOGIN</h1>
            
            <label for="username">Username</label>
            <input type="text" name="username" id="username" placeholder="Ingresa tu usuario" required>
            
            <label for="password">Password</label>
            <input type="password" name="password" id="password" placeholder="Ingresa tu contraseña" required>
            
            <button type="submit">Login</button>
        </form>

    
</body>
</html>