<?php
include "models/header.php";
include "../config/db.php";

// Verificar si se han enviado las fechas del filtro
$start_date = isset($_POST['start_date']) ? $_POST['start_date'] : '';
$end_date = isset($_POST['end_date']) ? $_POST['end_date'] : '';

// Construir la consulta para filtrar por fechas
$sql = "SELECT id, fecha, total FROM ventas WHERE 1=1";

// Si se han enviado fechas, agregar el filtro a la consulta
if ($start_date && $end_date) {
    $sql .= " AND fecha BETWEEN '$start_date' AND '$end_date'";
} elseif ($start_date) {
    $sql .= " AND fecha >= '$start_date'";
} elseif ($end_date) {
    $sql .= " AND fecha <= '$end_date'";
}

$sql .= " ORDER BY fecha DESC";  // Ordenar por fecha de forma descendente
$result = $conn->query($sql);
?>

<main class="mdl-layout__content">
    <div class="mdl-grid">
        <div class="mdl-cell mdl-cell--12-col">
            <h5>Historial de Ventas</h5>

            <!-- Formulario de Filtro por Fecha -->
            <form method="POST">
                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                    <input type="date" id="start_date" name="start_date" class="mdl-textfield__input" value="<?php echo htmlspecialchars($start_date); ?>">
                </div>
                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                    <input type="date" id="end_date" name="end_date" class="mdl-textfield__input" value="<?php echo htmlspecialchars($end_date); ?>">
                </div>
                <button type="submit" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored">
                    Filtrar
                </button>
            </form>

            <br>

            <!-- Mostrar la Tabla de Ventas -->
            <?php if ($result->num_rows > 0): ?>
                <table class="mdl-data-table mdl-js-data-table mdl-shadow--2dp">
                    <thead>
                        <tr>
                            <th>ID Venta</th>
                            <th>Fecha</th>
                            <th>Total</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo $row['fecha']; ?></td>
                                <td>$<?php echo number_format($row['total'], 2); ?></td>
                                <td>
                                    <a href="./models/detalle_venta.php?id=<?php echo $row['id']; ?>" 
                                       class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored">
                                        Ver Detalle
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No hay ventas registradas en este rango de fechas.</p>
            <?php endif; ?>
        </div>
    </div>
</main>

<script src="https://cdnjs.cloudflare.com/ajax/libs/material-design-lite/1.3.0/material.min.js"></script>
</body>
</html>
