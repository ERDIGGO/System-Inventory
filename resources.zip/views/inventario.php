<?php
    include "models/header.php";
?>

<!-- Buscador de productos -->
<div class="mdl-cell mdl-cell--12-col">
    <h5>Buscar Producto</h5>
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
        <input class="mdl-textfield__input" type="text" id="buscador" placeholder="Buscar producto...">
    </div>
    <div id="resultados" style="max-height: 300px; overflow-y: auto; border: 1px solid #ccc; margin-top: 10px;"></div>
</div>

<!-- Diálogo para agregar a la venta -->
<dialog class="mdl-dialog" id="dialogoAgregarVenta">
    <h4 class="mdl-dialog__title">Agregar a la Venta</h4>
    <div class="mdl-dialog__content">
        <p>¿Cuántas unidades desea agregar a la venta?</p>
        <input type="number" id="cantidadProducto" class="mdl-textfield__input" min="1" value="1">
    </div>
    <div class="mdl-dialog__actions">
        <button type="button" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored" id="confirmarAgregar">Agregar</button>
        <button type="button" class="mdl-button mdl-js-button" id="cancelarAgregar">Cancelar</button>
    </div>
</dialog>

<!-- Incluir JS de MDL -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/material-design-lite/1.3.0/material.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/dialog-polyfill/0.5.6/dialog-polyfill.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/dialog-polyfill/0.5.6/dialog-polyfill.min.css">

<script>
    // Buscador de productos
    document.getElementById('buscador').addEventListener('input', function () {
        let query = this.value;

        if (query.length > 2) {
            let xhr = new XMLHttpRequest();
            xhr.open('POST', './models/buscar_producto.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onload = function () {
                if (this.status === 200) {
                    document.getElementById('resultados').innerHTML = this.responseText;
                }
            };
            xhr.send('query=' + encodeURIComponent(query));
        } else {
            document.getElementById('resultados').innerHTML = '';
        }
    });

    // Variables del diálogo
    const dialog = document.getElementById('dialogoAgregarVenta');
    const confirmarAgregar = document.getElementById('confirmarAgregar');
    const cancelarAgregar = document.getElementById('cancelarAgregar');
    let productoId = null;

    // Mostrar diálogo para agregar a venta
    function agregarAVenta(id) {
        productoId = id;
        if (!dialog.showModal) {
            dialogPolyfill.registerDialog(dialog); // Compatibilidad con navegadores antiguos
        }
        dialog.showModal();
    }

    // Confirmar agregar producto
    confirmarAgregar.addEventListener('click', function () {
        let cantidad = document.getElementById('cantidadProducto').value;
        if (cantidad && cantidad > 0) {
            let xhr = new XMLHttpRequest();
            xhr.open('POST', './models/agregar_venta.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onload = function () {
                if (this.status === 200) {
                    alert(this.responseText); // Puedes reemplazar esto con SweetAlert2
                    dialog.close();
                }
            };
            xhr.send('id=' + productoId + '&cantidad=' + cantidad);
        } else {
            alert('Por favor, ingrese una cantidad válida.');
        }
    });

    // Cancelar agregar producto
    cancelarAgregar.addEventListener('click', function () {
        dialog.close();
    });
</script>

</body>
</html>
