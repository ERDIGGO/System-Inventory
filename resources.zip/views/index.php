<?php
include "models/header.php";
?>

<!-- CONTENIDO PRINCIPAL -->
<main class="mdl-layout__content">
    <div class="page-content">
        <h3 class="mdl-typography--text-center">📝 Historial de Actualizaciones</h3>
        <div class="mdl-grid">
            <!-- Tarjeta de Actualización -->
            <div class="mdl-cell mdl-cell--4-col">
                <div class="mdl-card mdl-shadow--2dp">
                    <div class="mdl-card__title mdl-card--expand mdl-color--primary mdl-color-text--white">
                        <h4>🚀 Versión 1.2.0</h4>
                    </div>
                    <div class="mdl-card__supporting-text">
                        <ul>
                            <li>✅ Nueva funcionalidad de búsqueda en tiempo real.</li>
                            <li>✅ Mejoras en el formulario de edición de productos.</li>
                            <li>✅ Corrección de errores en el carrito de compras.</li>
                        </ul>
                    </div>
                    <div class="mdl-card__actions mdl-card--border">
                        <span class="mdl-button mdl-button--colored">Fecha: 2024-06-01</span>
                    </div>
                </div>
            </div>

            <!-- Tarjeta de Actualización -->
            <div class="mdl-cell mdl-cell--4-col">
                <div class="mdl-card mdl-shadow--2dp">
                    <div class="mdl-card__title mdl-card--expand mdl-color--accent mdl-color-text--white">
                        <h4>🛠️ Versión 1.1.0</h4>
                    </div>
                    <div class="mdl-card__supporting-text">
                        <ul>
                            <li>✅ Optimización de la base de datos.</li>
                            <li>✅ Se agregó validación en formularios.</li>
                            <li>✅ Diseño responsivo mejorado.</li>
                        </ul>
                    </div>
                    <div class="mdl-card__actions mdl-card--border">
                        <span class="mdl-button mdl-button--colored">Fecha: 2024-05-20</span>
                    </div>
                </div>
            </div>

            <!-- Tarjeta de Actualización -->
            <div class="mdl-cell mdl-cell--4-col">
                <div class="mdl-card mdl-shadow--2dp">
                    <div class="mdl-card__title mdl-card--expand mdl-color--teal mdl-color-text--white">
                        <h4>📦 Versión 1.0.0</h4>
                    </div>
                    <div class="mdl-card__supporting-text">
                        <ul>
                            <li>✅ Lanzamiento inicial del sistema.</li>
                            <li>✅ Módulo de gestión de productos.</li>
                            <li>✅ Módulo de usuarios y permisos.</li>
                        </ul>
                    </div>
                    <div class="mdl-card__actions mdl-card--border">
                        <span class="mdl-button mdl-button--colored">Fecha: 2024-05-01</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tarjeta de Próximas Actualizaciones -->
        <h4 class="mdl-typography--text-center">✨ Próximas Actualizaciones</h4>
        <div class="mdl-grid">
            <div class="mdl-cell mdl-cell--12-col">
                <div class="mdl-card mdl-shadow--2dp">
                    <div class="mdl-card__title mdl-color--deep-orange mdl-color-text--white">
                        <h4>🔮 Próximamente...</h4>
                    </div>
                    <div class="mdl-card__supporting-text">
                        <ul>
                            <li>✅ Integración con pasarelas de pago.</li>
                            <li>✅ Sistema de notificaciones automáticas.</li>
                            <li>✅ Reportes avanzados de ventas.</li>
                        </ul>
                    </div>
                    <div class="mdl-card__actions mdl-card--border">
                        <span class="mdl-button mdl-button--colored">Fecha estimada: 2024-07-01</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<script src="https://cdnjs.cloudflare.com/ajax/libs/material-design-lite/1.3.0/material.min.js"></script>
</body>
</html>
