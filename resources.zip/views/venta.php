<?php
include "models/header.php";
include "../config/db.php";

// Obtener los productos agregados temporalmente
$sql = "SELECT vt.id, a.nombre, a.precio, vt.cantidad 
        FROM ventas_temp vt
        INNER JOIN articulos a ON vt.id_producto = a.id";
$result = $conn->query($sql);
$total = 0;
?>

<main class="mdl-layout__content">
    <div class="page-content">
        <div class="mdl-grid">
            <div class="mdl-cell mdl-cell--12-col">
                <h2 class="mdl-typography--text-center">🛒 Carrito de Ventas</h2>
                
                <div class="mdl-card mdl-shadow--4dp" style="padding: 20px; margin: 20px auto; width: 95%;">
                    <?php if ($result->num_rows > 0): ?>
                        <div style="overflow-x: auto; margin-bottom: 20px;">
                            <table class="mdl-data-table mdl-js-data-table mdl-shadow--2dp" style="width: 100%; font-size: 14px;">
                                <thead>
                                    <tr style="background-color: #f5f5f5;">
                                        <th class="mdl-data-table__cell--non-numeric">📝 Producto</th>
                                        <th class="mdl-data-table__cell--numeric">📦 Cantidad</th>
                                        <th class="mdl-data-table__cell--numeric">💲 Precio Unitario</th>
                                        <th class="mdl-data-table__cell--numeric">💵 Subtotal</th>
                                        <th class="mdl-data-table__cell--numeric">🗑️ Eliminar</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($row = $result->fetch_assoc()): 
                                        $subtotal = $row['precio'] * $row['cantidad'];
                                        $total += $subtotal;
                                    ?>
                                        <tr>
                                            <td class="mdl-data-table__cell--non-numeric"><?php echo htmlspecialchars($row['nombre']); ?></td>
                                            <td class="mdl-data-table__cell--numeric"><?php echo $row['cantidad']; ?></td>
                                            <td class="mdl-data-table__cell--numeric">$<?php echo number_format($row['precio'], 2); ?></td>
                                            <td class="mdl-data-table__cell--numeric">$<?php echo number_format($subtotal, 2); ?></td>
                                            <td class="mdl-data-table__cell--numeric">
                                                <form action="./models/eliminar_producto_venta.php" method="POST" style="margin: 0;">
                                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                                    <button type="submit" class="mdl-button mdl-js-button mdl-button--icon mdl-button--accent">
                                                        🗑️
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="mdl-card__actions mdl-card--border" style="text-align: right;">
                            <h4>Total: <span style="font-size: 1.5rem; color: #4CAF50;">$<?php echo number_format($total, 2); ?></span></h4>
                            <form action="./models/completar_venta.php" method="POST" style="display: inline-block;">
                                <button type="submit" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored" style="font-size: 1rem;">
                                    ✅ Completar Venta
                                </button>
                            </form>
                        </div>
                    <?php else: ?>
                        <div style="text-align: center; padding: 50px;">
                            <h4>🛑 No hay productos en el carrito.</h4>
                            <p>¡Agrega algunos productos para continuar con la venta!</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</main>

<style>
    /* Estilo para hacer el carrito más llamativo */
    .mdl-card {
        border-radius: 10px;
        background-color: #fff;
    }

    table.mdl-data-table {
        border-radius: 5px;
        overflow: hidden;
    }

    table.mdl-data-table thead tr {
        background: #f5f5f5;
    }

    table.mdl-data-table tbody tr:nth-child(even) {
        background: #fafafa;
    }

    table.mdl-data-table tbody tr:hover {
        background: #e8f5e9;
    }

    .mdl-card__actions {
        margin-top: 20px;
        padding-top: 10px;
        border-top: 1px solid #e0e0e0;
    }

    .mdl-button--icon {
        color: #D32F2F;
    }

    .mdl-button--icon:hover {
        background-color: #FFCDD2;
    }
</style>

<script src="https://cdnjs.cloudflare.com/ajax/libs/material-design-lite/1.3.0/material.min.js"></script>
</body>
</html>
