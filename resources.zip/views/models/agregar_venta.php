<?php
include "../../config/db.php";

if (isset($_POST['id']) && isset($_POST['cantidad'])) {
    $id = intval($_POST['id']);
    $cantidad = intval($_POST['cantidad']);

    // Validar existencia del producto
    $sql = "SELECT stock FROM articulos WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if ($cantidad <= $row['stock']) {
            // Aquí puedes agregar a una tabla de ventas temporal sin mostrar nada
            $sql_insert = "INSERT INTO ventas_temp (id_producto, cantidad) VALUES ($id, $cantidad)";
            if ($conn->query($sql_insert) !== TRUE) {
                // Si hay algún error, no se muestra nada
            }
        } 
        // Si no hay suficiente stock, no mostramos nada
    } 
    // Si el producto no es encontrado, no mostramos nada
    $conn->close();
}
?>
