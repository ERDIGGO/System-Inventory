<?php
include "../../config/db.php";

// Iniciar la venta
$sql = "SELECT vt.id_producto, vt.cantidad, a.precio, a.stock 
        FROM ventas_temp vt 
        INNER JOIN articulos a ON vt.id_producto = a.id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $total = 0;

    // Crear un registro de venta
    $sql_venta = "INSERT INTO ventas (fecha, total) VALUES (NOW(), 0)";
    $conn->query($sql_venta);
    $id_venta = $conn->insert_id;

    while ($row = $result->fetch_assoc()) {
        $id_producto = $row['id_producto'];
        $cantidad = $row['cantidad'];
        $precio = $row['precio'];
        $subtotal = $cantidad * $precio;
        $total += $subtotal;

        // Insertar detalles de la venta
        $sql_detalle = "INSERT INTO detalles_venta (id_venta, id_producto, cantidad, precio) 
                        VALUES ($id_venta, $id_producto, $cantidad, $precio)";
        $conn->query($sql_detalle);

        // Actualizar el stock
        $nuevo_stock = $row['stock'] - $cantidad;
        $sql_stock = "UPDATE articulos SET stock = $nuevo_stock WHERE id = $id_producto";
        $conn->query($sql_stock);
    }

    // Actualizar el total de la venta
    $sql_actualizar_total = "UPDATE ventas SET total = $total WHERE id = $id_venta";
    $conn->query($sql_actualizar_total);

    // Vaciar el carrito temporal
    $conn->query("DELETE FROM ventas_temp");

    echo "<script>window.location.href='../venta.php';</script>";
} else {
    echo "<script>alert('window.location.href='../venta.php';</script>";
}

$conn->close();
?>
