<?php
include "../../config/db.php"; // Asegúrate de que tu conexión esté incluida.

$query = isset($_POST['query']) ? $_POST['query'] : '';

// Evitar inyección SQL
$query = $conn->real_escape_string($query);

// Buscar productos por nombre o descripción
$sql = "SELECT id, nombre, descripcion, stock, precio FROM articulos WHERE nombre LIKE '%$query%' OR descripcion LIKE '%$query%'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "
    <table class='mdl-data-table mdl-js-data-table mdl-shadow--2dp'>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Stock</th>
                <th>Precio</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>";
        
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>" . htmlspecialchars($row['nombre']) . "</td>
                <td>" . htmlspecialchars($row['descripcion']) . "</td>
                <td>{$row['stock']}</td>
                <td>\$" . number_format($row['precio'], 2) . "</td>
                <td>
                    <button class='mdl-button mdl-js-button mdl-button--raised mdl-button--colored btn-editar' data-id='{$row['id']}'>
                        ✏️ Editar
                    </button>
                </td>
            </tr>";
    }
    
    echo "
        </tbody>
    </table>";
} else {
    echo "
    <table class='mdl-data-table mdl-js-data-table mdl-shadow--2dp'>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Stock</th>
                <th>Precio</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td colspan='6' style='text-align: center;'>No se encontraron resultados.</td>
            </tr>
        </tbody>
    </table>";
}
?>
