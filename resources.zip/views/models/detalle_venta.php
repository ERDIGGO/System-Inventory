<?php
include "../../config/db.php";

// Validar que se haya recibido un ID de venta
if (isset($_GET['id'])) {
    $id_venta = intval($_GET['id']);

    // Eliminar la venta si se solicita
    if (isset($_POST['eliminar'])) {
        $conn->begin_transaction();
        try {
            // Eliminar detalles de la venta
            $sql_delete_detalles = "DELETE FROM detalles_venta WHERE id_venta = $id_venta";
            $conn->query($sql_delete_detalles);

            // Eliminar la venta
            $sql_delete_venta = "DELETE FROM ventas WHERE id = $id_venta";
            $conn->query($sql_delete_venta);

            $conn->commit();
            echo "<script>window.location.href='../historial_ventas.php';</script>";
            exit;
        } catch (Exception $e) {
            $conn->rollback();
            echo "<script>alert('Error al eliminar la venta: {$e->getMessage()}');</script>";
        }
    }

    // Obtener información de la venta
    $sql_venta = "SELECT fecha, total FROM ventas WHERE id = $id_venta";
    $result_venta = $conn->query($sql_venta);
    $venta = $result_venta->fetch_assoc();

    // Obtener detalles de la venta
    $sql_detalles = "SELECT a.nombre, dv.cantidad, dv.precio 
                     FROM detalles_venta dv 
                     INNER JOIN articulos a ON dv.id_producto = a.id 
                     WHERE dv.id_venta = $id_venta";
    $result_detalles = $conn->query($sql_detalles);
} else {
    echo "<script>alert('ID de venta no válido'); window.location.href='historial_ventas.php';</script>";
    exit;
}
?>

<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.min.css">
<script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/dialog-polyfill/0.5.6/dialog-polyfill.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/dialog-polyfill/0.5.6/dialog-polyfill.min.css">

<style>
    /* --- General --- */
    body {
        background-color: #f9fafc;
        font-family: 'Roboto', sans-serif;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    .detalle-venta-container {
        max-width: 900px;
        width: 90%;
        background: #ffffff;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        margin: 0 auto; /* Centrado */
    }

    .detalle-venta-header {
        background: #ffffff;
        border-bottom: 1px solid #e0e0e0;
        padding: 20px;
        text-align: center;
    }

    .detalle-venta-header h5 {
        margin: 0;
        font-size: 24px;
        color: #333333;
        font-weight: 500;
    }

    .detalle-venta-info {
        display: flex;
        justify-content: space-between;
        padding: 20px;
        background: #fafafa;
        border-bottom: 1px solid #e0e0e0;
    }

    .detalle-venta-info p {
        margin: 0;
        font-size: 14px;
        color: #666666;
    }

    /* --- Tabla --- */
    .detalle-venta-table {
        margin: 20px auto; /* Centrado */
        width: 100%; /* Ajuste al 100% del contenedor */
        max-width: 800px; /* Limita el ancho máximo */
        border-collapse: collapse;
        font-size: 14px;
    }

    .detalle-venta-table th {
        text-align: left;
        background: #f5f5f5;
        color: #444444;
        font-weight: 500;
    }

    .detalle-venta-table th, .detalle-venta-table td {
        padding: 10px 15px;
        border-bottom: 1px solid #eeeeee;
    }

    .detalle-venta-table tr:hover {
        background: #f9f9f9;
    }

    .detalle-venta-table td {
        color: #555555;
    }

    /* --- Botones --- */
    .acciones-btn {
        margin: 20px;
        text-align: center;
    }

    .acciones-btn a,
    .acciones-btn button {
        text-decoration: none;
        display: inline-block;
        background: #0078d7;
        color: white;
        padding: 10px 25px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 500;
        margin: 5px;
        border: none;
        cursor: pointer;
    }

    .acciones-btn a:hover {
        background: #005bb5;
    }

    .acciones-btn a.imprimir {
        background: #28a745;
    }

    .acciones-btn a.imprimir:hover {
        background: #1e7e34;
    }

    .acciones-btn button.eliminar {
        background: #d9534f;
    }

    .acciones-btn button.eliminar:hover {
        background: #c9302c;
    }
</style>

<main class="mdl-layout__content">
    <div class="detalle-venta-container">
        <div class="detalle-venta-header">
            <h5>Detalle de la Venta #<?php echo $id_venta; ?></h5>
        </div>
        
        <div class="detalle-venta-info">
            <div>
                <p><strong>Fecha:</strong> <?php echo $venta['fecha']; ?></p>
            </div>
            <div>
                <p><strong>Total:</strong> $<?php echo number_format($venta['total'], 2); ?></p>
            </div>
        </div>

        <?php if ($result_detalles->num_rows > 0): ?>
            <table class="detalle-venta-table mdl-shadow--2dp">
                <thead>
                    <tr>
                        <th>Producto</th>
                        <th>Cantidad</th>
                        <th>Precio Unitario</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result_detalles->fetch_assoc()): 
                        $subtotal = $row['cantidad'] * $row['precio'];
                    ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['nombre']); ?></td>
                            <td><?php echo $row['cantidad']; ?></td>
                            <td>$<?php echo number_format($row['precio'], 2); ?></td>
                            <td>$<?php echo number_format($subtotal, 2); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <div class="acciones-btn">
            <a href="../historial_ventas.php">⬅️ Volver al Historial</a>
            <a href="generar_pdf.php?id=<?php echo $id_venta; ?>" target="_blank" class="imprimir">🖨️ Imprimir PDF</a>
            <button type="button" id="eliminarBtn" class="eliminar">🗑️ Eliminar Venta</button>
        </div>
    </div>
</main>

<!-- Diálogo de confirmación de eliminación -->
<dialog class="mdl-dialog" id="dialogoEliminarVenta">
    <h4 class="mdl-dialog__title">Confirmar Eliminación</h4>
    <div class="mdl-dialog__content">
        <p>¿Estás seguro de que deseas eliminar esta venta?</p>
    </div>
    <div class="mdl-dialog__actions">
        <button type="button" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored" id="confirmarEliminar">Eliminar</button>
        <button type="button" class="mdl-button mdl-js-button" id="cancelarEliminar">Cancelar</button>
    </div>
</dialog>

<script>
    const dialogEliminar = document.getElementById('dialogoEliminarVenta');
    const confirmarEliminar = document.getElementById('confirmarEliminar');
    const cancelarEliminar = document.getElementById('cancelarEliminar');
    const eliminarBtn = document.getElementById('eliminarBtn');

    // Asegurarse de que el polyfill esté registrado para el diálogo
    if (!dialogEliminar.showModal) {
        dialogPolyfill.registerDialog(dialogEliminar);
    }

    // Mostrar el diálogo de confirmación
    eliminarBtn.addEventListener('click', function() {
        dialogEliminar.showModal();
    });

    // Confirmar la eliminación
    confirmarEliminar.addEventListener('click', function () {
        // Enviar el formulario de eliminación
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '';
        form.innerHTML = '<input type="hidden" name="eliminar" value="true">';
        document.body.appendChild(form);
        form.submit();
    });

    // Cancelar la eliminación
    cancelarEliminar.addEventListener('click', function () {
        dialogEliminar.close();
    });
</script>
