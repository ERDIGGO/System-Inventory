<?php
session_start();
// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['username'])) {
    header("Location: ../index.php");
    exit();
}

// Obtener el nombre de usuario
$username = $_SESSION['username'];

include "../config/db.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="icon/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
    <script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>

    <title>system inventory</title>
</head>
<body>
<!-- Always shows a header, even in smaller screens. -->
<div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
  <!-- HEADER -->
  <header class="mdl-layout__header mdl-shadow--4dp">
    <div class="mdl-layout__header-row">
      <!-- Title -->
      <span class="mdl-layout-title">Hola, <?php echo $username; ?>.</span>
      <!-- Spacer -->
      <div class="mdl-layout-spacer"></div>
      <!-- Navigation (Visible solo en pantallas grandes) -->
      <nav class="mdl-navigation mdl-layout--large-screen-only">
        <a class="mdl-navigation__link" href="venta.php">Venta</a>
        <a class="mdl-navigation__link" href="inventario.php">Inventario</a>
        <a class="mdl-navigation__link" href="historial_ventas.php">Historial</a>
      </nav>
    </div>
  </header>

  <!-- DRAWER -->
  <div class="mdl-layout__drawer">
    <span class="mdl-layout-title">Menú</span>
    <nav class="mdl-navigation">
      <a class="mdl-navigation__link" href="articulos.php" title="Hay <?php echo $_SESSION['total_articulos']; ?> Articulos">Artículos</a>
      <a class="mdl-navigation__link" href="../config/logout.php">Cerrar Sesión</a>
    </nav>
  </div>
  