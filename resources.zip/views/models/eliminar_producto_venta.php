<?php
include "../../config/db.php";

if (isset($_POST['id'])) {
    $id = intval($_POST['id']);
    $sql = "DELETE FROM ventas_temp WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo "<script>window.location.href='../venta.php';</script>";
    } else {
        echo "Error al eliminar el producto: " . $conn->error;
    }
    $conn->close();
}
?>
