<?php
require_once('libs/tcpdf/tcpdf.php');
include "../../config/db.php";

// Validar que se haya recibido un ID de venta
if (isset($_GET['id'])) {
    $id_venta = intval($_GET['id']);

    // Obtener información de la venta
    $sql_venta = "SELECT fecha, total FROM ventas WHERE id = $id_venta";
    $result_venta = $conn->query($sql_venta);
    $venta = $result_venta->fetch_assoc();

    // Obtener detalles de la venta
    $sql_detalles = "SELECT a.nombre, dv.cantidad, dv.precio 
                     FROM detalles_venta dv 
                     INNER JOIN articulos a ON dv.id_producto = a.id 
                     WHERE dv.id_venta = $id_venta";
    $result_detalles = $conn->query($sql_detalles);
} else {
    die('ID de venta no válido');
}

// Crear una instancia de TCPDF
$pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);
$pdf->SetCreator('Sistema de Ventas');
$pdf->SetTitle('Detalle de Venta #' . $id_venta);
$pdf->SetHeaderData('', 0, 'Detalle de Venta', "Venta ID: $id_venta\nFecha: " . $venta['fecha']);
$pdf->setHeaderFont(['helvetica', '', 10]);
$pdf->setFooterFont(['helvetica', '', 8]);
$pdf->SetMargins(15, 27, 15);
$pdf->SetHeaderMargin(10);
$pdf->SetFooterMargin(10);
$pdf->SetAutoPageBreak(TRUE, 25);
$pdf->AddPage();

// Contenido del PDF
$html = '
    <h2 style="text-align: center;"> Detalle de la Venta #' . $id_venta . '</h2>
    <p><strong> Fecha:</strong> ' . $venta['fecha'] . '</p>
    <p><strong> Total:</strong> $' . number_format($venta['total'], 2) . '</p>
    <br>
    <table border="1" cellpadding="5" cellspacing="0">
        <thead>
            <tr style="background-color: #f2f2f2; text-align: center;">
                <th>Producto</th>
                <th>Cantidad</th>
                <th>Precio Unitario</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>';

if ($result_detalles->num_rows > 0) {
    while ($row = $result_detalles->fetch_assoc()) {
        $subtotal = $row['cantidad'] * $row['precio'];
        $html .= '
            <tr>
                <td>' . htmlspecialchars($row['nombre']) . '</td>
                <td style="text-align: center;">' . $row['cantidad'] . '</td>
                <td style="text-align: center;">$' . number_format($row['precio'], 2) . '</td>
                <td style="text-align: center;">$' . number_format($subtotal, 2) . '</td>
            </tr>';
    }
} else {
    $html .= '<tr><td colspan="4" style="text-align: center;">No hay detalles disponibles.</td></tr>';
}

$html .= '
        </tbody>
    </table>
    <br><br>
    <p style="text-align: center; font-size: 12px;">Gracias por su compra</p>';

// Escribir el HTML en el PDF
$pdf->writeHTML($html, true, false, true, false, '');

// Salida del PDF
$pdf->Output('detalle_venta_' . $id_venta . '.pdf', 'I');
?>
