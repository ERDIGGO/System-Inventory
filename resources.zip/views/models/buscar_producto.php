<?php
include "../../config/db.php";

if (isset($_POST['query'])) {
    $query = $_POST['query'];
    $sql = "SELECT id, nombre, stock, precio FROM articulos 
            WHERE nombre LIKE '%$query%' LIMIT 10";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<div style='padding: 10px; border-bottom: 1px solid #ddd; display: flex; justify-content: space-between; align-items: center;'>";
            echo "<div>";
            echo "<strong>" . htmlspecialchars($row['nombre']) . "</strong><br>";
            echo "Stock: " . $row['stock'] . " | Precio: $" . $row['precio'];
            echo "</div>";
            echo "<button onclick='agregarAVenta(" . $row['id'] . ")' class='mdl-button mdl-js-button mdl-button--raised mdl-button--colored'>Agregar</button>";
            echo "</div>";
        }
    } else {
        echo "<p>No se encontraron resultados.</p>";
    }
    $conn->close();
}
?>
