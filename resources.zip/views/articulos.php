<?php
include "models/header.php";

// Validar conexión
if ($conn->connect_error) {
    die("<p style='color:red;'>Conexión fallida: " . $conn->connect_error . "</p>");
}

// Verificar si se va a editar un producto
$editar_id = isset($_GET['editar']) ? intval($_GET['editar']) : null;
$producto_editar = null;

if ($editar_id) {
    $sql_editar = "SELECT * FROM articulos WHERE id = $editar_id";
    $result_editar = $conn->query($sql_editar);
    if ($result_editar->num_rows > 0) {
        $producto_editar = $result_editar->fetch_assoc();
    }
}

// Actualizar producto si se envía el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['editar_producto'])) {
    $id = intval($_POST['id']);
    $nombre = $conn->real_escape_string($_POST['nombre']);
    $descripcion = $conn->real_escape_string($_POST['descripcion']);
    $stock = intval($_POST['stock']);
    $precio = floatval($_POST['precio']);

    $sql_update = "UPDATE articulos SET nombre='$nombre', descripcion='$descripcion', stock=$stock, precio=$precio WHERE id=$id";
    if ($conn->query($sql_update)) {
        echo "<script>window.location.href='articulos.php';</script>";
    } else {
        echo "<p style='color:red;'>Error al actualizar el producto: " . $conn->error . "</p>";
    }
}

// Obtener todos los productos
$sql = "SELECT id, nombre, descripcion, stock, precio FROM articulos";
$result = $conn->query($sql);
?>

<!-- Contenido principal -->
<main class="mdl-layout__content">
    <div class="mdl-grid">
        <!-- Buscador -->
        <div class="mdl-cell mdl-cell--8-col">
            <h5>Buscar Productos</h5>
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                <input class="mdl-textfield__input" type="text" id="buscarProducto" placeholder="Buscar producto...">
            </div>
        </div>

        <!-- Tabla de artículos -->
        <div class="mdl-cell mdl-cell--8-col">
            <h5>Lista de Productos</h5>
            <div id="tablaProductos">
                <?php if ($result->num_rows > 0): ?>
                    <table class='mdl-data-table mdl-js-data-table mdl-shadow--2dp'>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Descripción</th>
                                <th>Stock</th>
                                <th>Precio</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo htmlspecialchars($row['nombre']); ?></td>
                                    <td><?php echo htmlspecialchars($row['descripcion']); ?></td>
                                    <td><?php echo $row['stock']; ?></td>
                                    <td>$<?php echo number_format($row['precio'], 2); ?></td>
                                    <td>
                                        <a href="?editar=<?php echo $row['id']; ?>" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored">
                                            ✏️ Editar
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No hay productos disponibles.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Formulario de agregar o editar producto -->
        <div class="mdl-cell mdl-cell--4-col">
            <?php if ($producto_editar): ?>
                <h5>Editar Producto</h5>
                <form action="articulos.php" method="POST">
                    <input type="hidden" name="id" value="<?php echo $producto_editar['id']; ?>">
                    <input type="hidden" name="editar_producto" value="1">

                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                        <input class="mdl-textfield__input" type="text" name="nombre" value="<?php echo $producto_editar['nombre']; ?>" required>
                        <label class="mdl-textfield__label" for="nombre">Nombre del Producto</label>
                    </div>

                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                        <input class="mdl-textfield__input" type="number" name="stock" value="<?php echo $producto_editar['stock']; ?>" required>
                        <label class="mdl-textfield__label" for="stock">Stock</label>
                    </div>

                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                        <input class="mdl-textfield__input" type="number" step="0.01" name="precio" value="<?php echo $producto_editar['precio']; ?>" required>
                        <label class="mdl-textfield__label" for="precio">Precio</label>
                    </div>

                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                        <textarea class="mdl-textfield__input" name="descripcion"><?php echo $producto_editar['descripcion']; ?></textarea>
                        <label class="mdl-textfield__label" for="descripcion">Descripción</label>
                    </div>

                    <button type="submit" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored">Actualizar Producto</button>
                </form>
            <?php else: ?>
                <h5>Agregar Nuevo Producto</h5>
                <form action="../config/add_product.php" method="POST">
                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                        <input class="mdl-textfield__input" type="text" name="nombre" required>
                        <label class="mdl-textfield__label" for="nombre">Nombre del Producto</label>
                    </div>

                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                        <input class="mdl-textfield__input" type="number" name="stock" required>
                        <label class="mdl-textfield__label" for="stock">Stock</label>
                    </div>

                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                        <input class="mdl-textfield__input" type="number" step="0.01" name="precio" required>
                        <label class="mdl-textfield__label" for="precio">Precio</label>
                    </div>

                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                        <textarea class="mdl-textfield__input" name="descripcion"></textarea>
                        <label class="mdl-textfield__label" for="descripcion">Descripción</label>
                    </div>

                    <button type="submit" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored">Guardar Producto</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</main>

<!-- Script para búsqueda AJAX -->
<script>
    document.getElementById('buscarProducto').addEventListener('input', function() {
        let query = this.value;
        let xhr = new XMLHttpRequest();
        xhr.open('POST', 'models/search.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function() {
            if (this.status === 200) {
                document.getElementById('tablaProductos').innerHTML = this.responseText;
                componentHandler.upgradeDom(); // Actualiza Material Design Lite
                agregarEventosEditar(); // Vuelve a agregar los eventos de edición
            }
        };
        xhr.send('query=' + query);
    });

    // Función para agregar eventos a los botones editar después de AJAX
    function agregarEventosEditar() {
        document.querySelectorAll('.btn-editar').forEach(boton => {
            boton.addEventListener('click', function(e) {
                e.preventDefault();
                const id = this.dataset.id;
                window.location.href = `?editar=${id}`;
            });
        });
    }

    // Llamar la función al cargar la página por primera vez
    agregarEventosEditar();
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/material-design-lite/1.3.0/material.min.js"></script>
</body>
</html>
