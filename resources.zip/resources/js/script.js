// Función para generar un código aleatorio de 10 dígitos
function generarCodigoAleatorio() {
    let codigo = '';
    for (let i = 0; i < 10; i++) {
        // Agrega un número aleatorio entre 0 y 9
        codigo += Math.floor(Math.random() * 10);
    }
    return codigo;
}

// Ejemplo de uso
const codigoGenerado = generarCodigoAleatorio();
console.log("Código aleatorio de 10 dígitos:", codigoGenerado);
